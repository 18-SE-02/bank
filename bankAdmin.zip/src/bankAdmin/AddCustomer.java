package bankAdmin;

import java.awt.*;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Random;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class AddCustomer extends JDialog implements ActionListener{

	 //��������Ҫ��swing���
	JLabel jl2,jl5,jl6,jl7;
	JTextField jf1,jf2,jf5,jf6,jf7;
	JPanel jp1,jp2,jp3;
	JButton jb1,jb2;	
	String cardNumber;
	
	//owner���ʸ�����,title�Ǵ��ڵ�����,modalָ����ģʽ����()���߷�ģʽ����
	 public AddCustomer(Frame owner,String title, boolean modal){
		 super(owner,title,modal);
//		 jl1 = new JLabel("����");
		 jl2 = new JLabel("����");
		 jl5 = new JLabel("����");
		 jl6 = new JLabel("�绰����");
		 jl7 = new JLabel("����֤����");
		 
//		 jf1 = new JTextField(20);
		 jf2 = new JTextField(20);
		 jf5 = new JTextField(20);
		 jf6 = new JTextField(20);
		 jf7 = new JTextField(20);
		 
		 jb1 = new JButton("����");
		 jb1.addActionListener(this);
		 jb2 = new JButton("ȡ��");
		 jb2.addActionListener(this);
		 
		 jp1 = new JPanel();
		 jp2 = new JPanel();
		 jp3 = new JPanel();

		 //���ò���
		 jp1.setLayout(new GridLayout(7,1));
		 jp2.setLayout(new GridLayout(7,1));

		 jp3.add(jb1);
		 jp3.add(jb2);

//		 jp1.add(jl1);
		 jp1.add(jl2);
		 jp1.add(jl5);
		 jp1.add(jl6);
		 jp1.add(jl7);

//		 jp2.add(jf1);
		 jp2.add(jf2);
		 jp2.add(jf5);
		 jp2.add(jf6);
		 jp2.add(jf7);

		 this.add(jp1, BorderLayout.WEST);
		 this.add(jp2, BorderLayout.CENTER);
		 this.add(jp3, BorderLayout.SOUTH);

		 this.setSize(500,300);
		 this.setVisible(true);
		 this.getContentPane().setLayout(null);
		 this.setLocation(500, 150);
		  
	 }
	
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		if(arg0.getSource() == jb1){
			String name,password,telephone,idNum;
			Double balance,loan;
			name = jf2.getText();
			password = jf5.getText();
			telephone = jf6.getText();
			
			
			
			
//			int[] month_to_day ={ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
//	        if(this.getIdNumber() == null || this.getIdNumber().length() == 0){
//	            addFieldError("idNumber","����֤���벻��Ϊ�գ�");//�������18�겻�ܰ������п�
//	        }else if(this.getIdNumber().length() != 18){
//	            addFieldError("idNumber","����֤���볤�ȴ���");
//	        }else if((this.getIdNumber().toCharArray()[17] < '0' || this.getIdNumber().toCharArray()[17] > '9')
//	                && this.getIdNumber().toCharArray()[17] != 'X' && this.getIdNumber().toCharArray()[17] != 'x'){
//	            addFieldError("idNumber","����֤�������");
//	        }else if(judge(this.getIdNumber()) == true){
//	             addFieldError("idNumber","����֤�������");
//	        }else {
//	            int month, day;
//	            month = ((int)this.getIdNumber().toCharArray()[10] - 48)*10+((int)this.getIdNumber().toCharArray()[11] - 48);
//	            day = ((int)this.getIdNumber().toCharArray()[12] - 48)*10+((int)this.getIdNumber().toCharArray()[13] - 48);
//	                if((month > 12) || (day > month_to_day[month-1])){
//	                addFieldError("idNumber","����֤�������");
//	            }else{   
//	                CustomerDAO info=new CustomerDAO();
//	                list=info.queryInfo("idNumber", this.getIdNumber());
//	                UserInfoPO ui=new UserInfoPO();
//	                for(int i=0;i<list.size();i++){
//	                    ui=(UserInfoPO)list.get(i);
//	                    if(ui.getIdNumber().equals(this.getIdNumber())){
//	                        addFieldError("idNumber","����֤�����Ѵ��ڣ�");
//	                        break;
//	                    }
//	                }
//	            }
//	        }
//	            
//	        if(this.getPassword1() == null || this.getPassword1().length() == 0){
//	            addFieldError("password1","��¼���벻����Ϊ�գ�");
//	        }else if(judge(this.getPassword1()) == true){
//	            addFieldError("password1","��¼����ֻ��Ϊ���֣�");
//	        }else if(this.getPassword1().length() != 6){
//	            addFieldError("password1","��¼���볤��ֻ��Ϊ6��");
//	        }else if(!this.getPassword1().equals(this.getPassword2())){
//	            addFieldError("password2","�������벻һ�£�");
//	        }
//	        
//	        if(this.getName()==null||this.getName().length()==0){
//	            addFieldError("name","����������Ϊ�գ�");
//	        }else{
//	            for(int i = 0; i < this.getName().length(); i++){
//	                if((this.getName().toCharArray()[i]+"").getBytes().length == 1){
//	                    addFieldError("name","����������������ĸ�����ֻ��ַ���");
//	                    break;
//	                }
//	            }
//	        }
//	        if(this.getTelephone()==null||this.getTelephone().length()==0){
//	            addFieldError("telephone","�绰������Ϊ�գ�");
//	        }else if(this.getTelephone().length() != 11){
//	            addFieldError("telephone","�绰���ȴ���");
//	        }else if(this.getTelephone().toCharArray()[0] != '1'){
//	            addFieldError("telephone","�绰�������");
//	        }else{
//	            for(int i = 0; i < this.getTelephone().length(); i++){
//	                if(this.getTelephone().toCharArray()[i] > '9' || this.getTelephone().toCharArray()[i] < '0'){
//	                    addFieldError("telephone","�绰����ֻ�������֣�");
//	                    break;
//	                }
//	            }
//	        }
//	    }
//	    
//	    public boolean judge(String idnumber){
//	        for(int i = 0; i <idnumber.length() ; i++){
//	            if(idnumber.toCharArray()[i] < '0' || idnumber.toCharArray()[i] > '9'){
//	                return true;
//	                }
//	        }
//	        return false;
//	    }
//	    
//	    
//	    public UserInfoPO userInfo(){
//	        UserInfoPO info=new UserInfoPO();
//	        info.setName(this.getName());
//	        info.setPassword(this.getPassword1()); 
//	        info.setIdNumber(this.getIdNumber());
//	        info.setTelephone(this.getTelephone());
//	        info.setCardNumber(cardNum());
//	        return info;
//	    }
//	    
	    
			Connection ct = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			
			try{
				//1.��������
			    Class.forName("com.mysql.jdbc.Driver");
			    System.out.println("���سɹ�");
			    //2.�������ݿ�
			    ct = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank", "root", "root");

			    //�����������

			    String strsql = "insert into customer1 values(?,?,?,?,?,?,?,?,?)";
			    pstmt = ct.prepareStatement(strsql);
			  
//			    cardNum="123";
			    //������ֵ
			    pstmt.setString(1,getCardNumber());
			    pstmt.setString(2,jf2.getText());
			    pstmt.setString(3,"0");
			    pstmt.setString(4,"0");
			    pstmt.setString(5,jf5.getText());
			    pstmt.setString(6,jf6.getText());
			    pstmt.setString(7,jf7.getText());
			    pstmt.setString(8,"0");
			    pstmt.setString(9,"0");

			    pstmt.executeUpdate();

			    this.dispose();//�ر�ѧ���Ի���

			   }catch(Exception arg1){
				   arg1.printStackTrace();
			   }finally{
				   try{
					   if(rs!=null){
						   rs.close();
						   rs = null;
					   }
					   if(pstmt != null){
						   pstmt.close();
						   pstmt = null;
					   }
					   if(ct != null){
						   ct.close();
						   ct = null;
					   }
				   }catch(Exception arg2){
					   arg2.printStackTrace();
				   }
			   }
		}
		
		else if(arg0.getSource() == jb2){
			System.out.println("��ѡ����ȡ��");
			this.dispose();//�ر����ӶԻ���
		}
	}

	public String getCardNumber() {
		 String[] start = {"4367", "6227", "62288", "6222", "6221", "6013", "4563", "6210", "6222"};
	     Random rand = new Random();
	     int number = rand.nextInt(9);
	     cardNumber = start[number];
	     for (int i = start[number].length(); i < 19; i++) {
	    	 cardNumber += rand.nextInt(10);
	     }
	     return cardNumber;
	}

}
