package bankMaster;

public class Test {
	public static void main(String[] args) {
		Login W = new Login();
	}
}
