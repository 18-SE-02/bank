package bankService;

import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Reply extends JDialog implements ActionListener{
	JLabel reply1;
	TextArea text;
	JPanel jp1, jp2, jp3;
	JButton jb1, jb2;
	PreparedStatement ps;
	String date;
	
	// owner���ʸ�����,title�Ǵ��ڵ�����,modalָ����ģʽ����()���߷�ģʽ����
		public Reply(Frame owner, String title, boolean modal, AdviseModel am, int rowNum) {
			super(owner, title, modal);
			reply1 = new JLabel("�ظ�����Ϊ");
			text = new TextArea(10, 40);
			text.setText(am.getValueAt(rowNum, 4).toString());
			date = (String) am.getValueAt(rowNum, 0);
			
			jb1 = new JButton("ȷ��");
			jb1.addActionListener(this);
			jb2 = new JButton("ȡ��");
			jb2.addActionListener(this);

			jp1 = new JPanel();
			jp2 = new JPanel();
			jp3 = new JPanel();
			
			// ���ò���
			jp1.setLayout(new GridLayout(1, 1));
			jp2.setLayout(new GridLayout(1, 1));

			jp3.add(jb1);
			jp3.add(jb2);

			jp1.add(reply1);

			jp2.add(text);
			
			this.add(jp1, BorderLayout.WEST);
			this.add(jp2, BorderLayout.CENTER);
			this.add(jp3, BorderLayout.SOUTH);

			this.setSize(280,160);
	        this.setLocationRelativeTo(null);    
	        this.setVisible(true);
		}
		
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			if (arg0.getSource() == jb1) {
				Connection ct = null;
				PreparedStatement pstmt = null;
				ResultSet rs = null;
				Statement stmt = null;

				try {
					// 1.��������
					Class.forName("com.mysql.jdbc.Driver");
					// 2.�������ݿ�
					ct = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank", "root", "root");
					stmt = ct.createStatement();

					String sql = 
							"update leavemessage set reply = '" + text.getText() + "' where date= '" + date + "'";
					stmt.executeUpdate(sql);

					this.dispose();

				} catch (Exception arg1) {
					arg1.printStackTrace();
				}
			}

			else if (arg0.getSource() == jb2) {
				this.dispose();
			}
		}
	
}
