package bankService;

public class Test {
	public static void main(String[] args) {
		Login W = new Login();
	}
}
